
document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");
  const username = document.querySelector('input[type="text"]');
  const password = document.querySelector('input[type="password"]');
  const submitBtn = document.querySelector('button[type="submit"]');

  const togglePassword = document.createElement("span");
  togglePassword.innerHTML = "";
  togglePassword.style.cursor = "pointer";
  togglePassword.style.position = "absolute";
  togglePassword.style.right = "10px";
  togglePassword.style.top = "50%";
  togglePassword.style.transform = "translateY(-50%)";
  togglePassword.style.fontSize = "18px";
  togglePassword.title = "Show password";

  const passwordGroup = password.parentElement;
  passwordGroup.style.position = "relative";
  passwordGroup.appendChild(togglePassword);

  togglePassword.addEventListener("click", function () {
    const type = password.getAttribute("type") === "password" ? "text" : "password";
    password.setAttribute("type", type);
    this.textContent = type === "password" ? "👁️" : "🙈";
  });

  // Real-time validation feedback
  function showError(input, message) {
    const error = document.createElement("small");
    error.style.color = "#FF1493";
    error.textContent = message;
    if (!input.parentElement.querySelector("small")) {
      input.parentElement.appendChild(error);
    }
  }

  function clearError(input) {
    const error = input.parentElement.querySelector("small");
    if (error) error.remove();
  }

  // Validate username
  username.addEventListener("input", function () {
    clearError(username);
    if (username.value.trim().length < 3) {
      showError(username, "Username must be at least 3 characters");
    }
  });

  // Validate password strength
  password.addEventListener("input", function () {
    clearError(password);
    const value = password.value;
    if (value.length < 8) {
      showError(password, "Password must be at least 6 characters");
    } else if (!/[A-Z]/.test(value)) {
      showError(password, "Include at least one uppercase letter");
    } else if (!/[0-9]/.test(value)) {
      showError(password, "Include at least one number");
    }
  });

  // Form submission
  form.addEventListener("submit", function (e) {
    e.preventDefault(); // Stop actual submission (for demo)

    // Final check
    let isValid = true;

    if (username.value.trim().length < 3) {
      showError(username, "Valid username required");
      isValid = false;
    }
    if (password.value.length < 8 || !/[A-Z]/.test(password.value) || !/[0-9]/.test(password.value)) {
      showError(password, "Strong password required");
      isValid = false;
    }

    if (isValid) {
      // Success animation
      submitBtn.textContent = "Welcome!";
      submitBtn.style.backgroundColor = "#FF69B4";
      submitBtn.disabled = true;

      setTimeout(() => {
        alert(`Welcome, ${username.value}! Successful`);
        form.reset();
        submitBtn.textContent = "Sign Up";
        submitBtn.disabled = false;
        submitBtn.style.backgroundColor = "#FFB6C1";
      }, 1500);
    }
  });